package com.sharks.launcher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SectionTitle(t: String) {
    Text(t, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 16.dp, bottom = 12.dp))
}

@Composable
fun Hint(t: String) {
    Text(t, color = Color(0xAAFFFFFF), fontSize = 17.sp, modifier = Modifier.padding(vertical = 8.dp).widthIn(max = 700.dp))
}

@Composable
fun Retry(text: String, onRetry: () -> Unit) {
    Column {
        Hint(text)
        Spacer(Modifier.height(8.dp))
        ActionButton("Повторить", true, null, onRetry)
    }
}

@Composable
fun Sidebar(current: Section, onSelect: (Section) -> Unit) {
    Column(
        Modifier.width(132.dp).fillMaxHeight().padding(top = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Section.values().forEach { s ->
            var focused by remember { mutableStateOf(false) }
            val sel = s == current
            Column(
                Modifier.width(104.dp).height(72.dp)
                    .onFocusChanged { focused = it.isFocused; if (it.isFocused) onSelect(s) }
                    .background(
                        if (sel) Brush.verticalGradient(listOf(lerp(Red, Color.White, 0.12f), lerp(Red, Color.Black, 0.45f))) else SolidColor(Color.Transparent),
                        RoundedCornerShape(20.dp)
                    )
                    .border(if (focused) 3.dp else 0.dp, if (focused) Color.White else Color.Transparent, RoundedCornerShape(20.dp))
                    .clickable { onSelect(s) }.focusable(),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Icon(painterResource(s.icon), s.label, Modifier.size(28.dp), tint = if (sel || focused) Color.White else Color(0xFFB0B0B0))
                Spacer(Modifier.height(4.dp))
                Text(s.label, color = if (sel || focused) Color.White else Color(0xFFB0B0B0), fontSize = 13.sp, maxLines = 1)
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun SearchBar(query: String, onChange: (String) -> Unit, onMic: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val kb = LocalSoftwareKeyboardController.current
    Row(
        Modifier.fillMaxWidth().height(60.dp)
            .background(Glass, RoundedCornerShape(30.dp))
            .border(if (focused) 3.dp else 1.dp, if (focused) Red else GlassBorder, RoundedCornerShape(30.dp))
            .padding(start = 24.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(painterResource(R.drawable.ic_search), null, Modifier.size(28.dp), tint = Color(0xFFCCCCCC))
        Spacer(Modifier.width(16.dp))
        BasicTextField(
            value = query, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 22.sp),
            cursorBrush = SolidColor(Red),
            modifier = Modifier.weight(1f)
                .onFocusChanged { focused = it.isFocused }
                .onPreviewKeyEvent { e ->
                    if (e.type == KeyEventType.KeyUp && (e.key == Key.DirectionCenter || e.key == Key.Enter)) { kb?.show(); true } else false
                },
            decorationBox = { inner ->
                if (query.isEmpty()) Text("Поиск приложений и контента…", color = Color(0x99FFFFFF), fontSize = 22.sp)
                inner()
            }
        )
        var micFocused by remember { mutableStateOf(false) }
        Box(
            Modifier.size(44.dp)
                .onFocusChanged { micFocused = it.isFocused }
                .background(if (micFocused) Color(0x33FFFFFF) else Color.Transparent, RoundedCornerShape(50))
                .border(if (micFocused) 2.dp else 0.dp, if (micFocused) Red else Color.Transparent, RoundedCornerShape(50))
                .clickable(onClick = onMic).focusable(),
            contentAlignment = Alignment.Center
        ) { Icon(painterResource(R.drawable.ic_mic), "Голосовой поиск", Modifier.size(26.dp), tint = Color.White) }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCard(
    title: String, icon: ImageBitmap?, accent: Color, onLong: (() -> Unit)?,
    plus: Boolean = false, iconRes: Int? = null, onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.1f else 1f, tween(160), label = "s")
    val shape = RoundedCornerShape(22.dp)
    Box(
        Modifier.width(190.dp).height(118.dp).scale(scale)
            .then(if (focused) Modifier.shadow(18.dp, shape, ambientColor = Red, spotColor = Red) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .background(Glass, shape)
            .border(if (focused) 3.dp else 1.dp, if (focused) Red else GlassBorder, shape)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .focusable(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            when {
                plus -> Icon(painterResource(R.drawable.ic_add), null, Modifier.size(52.dp), tint = Color.White)
                iconRes != null -> Icon(painterResource(iconRes), null, Modifier.size(52.dp), tint = Color.White)
                icon != null -> Image(icon, title, Modifier.size(64.dp))
                else -> Box(Modifier.size(64.dp).background(accent, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Text(title.take(1).uppercase(), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(title, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 8.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PosterCard(f: Film, w: Dp, onLong: (() -> Unit)?, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.08f else 1f, tween(160), label = "s")
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.width(w).scale(scale)) {
        Box(
            Modifier.width(w).height(w * 1.45f)
                .then(if (focused) Modifier.shadow(18.dp, shape, ambientColor = Red, spotColor = Red) else Modifier)
                .onFocusChanged { focused = it.isFocused }
                .clip(shape).background(Color(0xFF1A1A1A))
                .border(if (focused) 3.dp else 0.dp, if (focused) Red else Color.Transparent, shape)
                .combinedClickable(onClick = onClick, onLongClick = onLong)
                .focusable()
        ) {
            AsyncImage(f.poster, f.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Spacer(Modifier.height(8.dp))
        Text(f.title, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(listOf(f.year, f.rating).filter { it.isNotBlank() }.joinToString(" · "), color = Color(0x99FFFFFF), fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun ActionButton(text: String, primary: Boolean, requester: FocusRequester?, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.08f else 1f, tween(160), label = "s")
    Box(
        Modifier.scale(scale).then(if (requester != null) Modifier.focusRequester(requester) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .background(if (primary) Red else Glass, RoundedCornerShape(30.dp))
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else GlassBorder, RoundedCornerShape(30.dp))
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 26.dp, vertical = 13.dp)
    ) { Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun SettingsButton(onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.12f else 1f, tween(160), label = "s")
    Box(
        Modifier.scale(scale).size(58.dp)
            .onFocusChanged { focused = it.isFocused }
            .background(if (focused) Color(0xFF2A2A2A) else Glass, RoundedCornerShape(50))
            .border(if (focused) 3.dp else 1.dp, if (focused) Red else GlassBorder, RoundedCornerShape(50))
            .clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) { Icon(painterResource(R.drawable.ic_gear), "Настройки", Modifier.size(30.dp), tint = Color.White) }
}

@Composable
fun VpnButton(on: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val color by animateColorAsState(if (on) Color(0xFF2ECC71) else Color(0xFFCCCCCC), tween(250), label = "c")
    val scale by animateFloatAsState(if (focused) 1.1f else 1f, tween(160), label = "s")
    Row(
        Modifier.scale(scale).height(58.dp)
            .onFocusChanged { focused = it.isFocused }
            .background(if (focused) Color(0xFF2A2A2A) else Glass, RoundedCornerShape(50))
            .border(if (focused) 3.dp else 1.dp, if (focused) Red else GlassBorder, RoundedCornerShape(50))
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 28.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(12.dp).background(color, RoundedCornerShape(50)))
        Spacer(Modifier.width(12.dp))
        Text(if (on) "VPN Вкл" else "VPN Выкл", color = color, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

/** Статус сети + часы и дата в шапке. Обновляется сам, не перерисовывая остальной экран. */
@Composable
fun StatusBar() {
    val ctx = LocalContext.current
    var time by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var net by remember { mutableStateOf(1) }
    LaunchedEffect(Unit) {
        val tf = SimpleDateFormat("HH:mm", Locale("ru"))
        val df = SimpleDateFormat("EEE, d MMMM", Locale("ru"))
        while (true) {
            val now = Date()
            time = tf.format(now)
            date = df.format(now).replaceFirstChar { it.uppercase() }
            net = ctx.networkKind()
            delay(2000)
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Icon(
            painterResource(if (net == 2) R.drawable.ic_ethernet else R.drawable.ic_wifi), null, Modifier.size(26.dp),
            tint = if (net == 0) Color(0xFFFF5252) else Color(0xCCFFFFFF)
        )
        Column(horizontalAlignment = Alignment.End) {
            Text(time, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(date, color = Color(0x99FFFFFF), fontSize = 13.sp)
        }
    }
}

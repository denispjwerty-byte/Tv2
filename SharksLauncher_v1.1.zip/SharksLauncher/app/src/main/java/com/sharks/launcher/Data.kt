package com.sharks.launcher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------- тема и конфигурация ----------
/** Акцентный цвет берётся из выбранных обоев. */
object Theme { var accent by mutableStateOf(Color(0xFFE50914)) }
val Red: Color get() = Theme.accent
val Glass = Color(0x26FFFFFF)
val GlassBorder = Color(0x22FFFFFF)

/**
 * Ключ API КиноПоиска: из BuildConfig (local.properties / секрет CI KP_API_KEY),
 * либо вводится прямо в лаунчере: шестерёнка → «Настройки лаунчера».
 */
object Config { var kpKey: String = BuildConfig.KP_API_KEY }

// ---------- приложения ----------
data class AppItem(val title: String, val packages: List<String>, val labels: List<String>, val accent: Color)

val HAPP_PACKAGES = listOf("com.happproxy", "com.happproxy.android", "com.happ.android")

val APPS = listOf(
    AppItem("YouTube", listOf("com.google.android.youtube.tv", "com.google.android.youtube"), listOf("youtube"), Color(0xFFFF0033)),
    AppItem("Happ", HAPP_PACKAGES, listOf("happ"), Color(0xFF19B5FE)),
    AppItem("Google Play", listOf("com.android.vending"), listOf("play маркет", "play store", "google play"), Color(0xFF34A853)),
    AppItem("КиноПоиск", listOf("ru.kinopoisk", "ru.kinopoisk.tv"), listOf("кинопоиск", "kinopoisk"), Color(0xFFFF6600)),
    AppItem("Downloader", listOf("com.esaba.downloader"), listOf("downloader"), Color(0xFFFF9800)),
    AppItem("Файловый менеджер", listOf("com.google.android.apps.nbu.files", "com.android.documentsui",
        "com.google.android.documentsui", "com.android.fileexplorer", "com.droidlogic.FileBrower", "com.softwinner.TvdFileManager"),
        listOf("файловый менеджер", "file manager", "files", "файлы"), Color(0xFF9C6BFF)),
    AppItem("CX Проводник", listOf("com.cxinventor.file.explorer"), listOf("cx "), Color(0xFF2196F3)),
)

fun Context.launchIntentFor(pkg: String): Intent? =
    packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: packageManager.getLaunchIntentForPackage(pkg)

fun Context.allLaunchable(): List<ResolveInfo> {
    val pm = packageManager
    val a = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
    val b = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
    return (a + b).distinctBy { it.activityInfo.packageName }
        .filter { it.activityInfo.packageName != packageName }
        .sortedBy { it.loadLabel(pm).toString().lowercase() }
}

fun Context.resolvePackage(item: AppItem): String? {
    item.packages.firstOrNull { launchIntentFor(it) != null }?.let { return it }
    if (item.labels.isEmpty()) return null
    return allLaunchable().firstOrNull { ri ->
        val l = ri.loadLabel(packageManager).toString().lowercase()
        item.labels.any { l.contains(it) }
    }?.activityInfo?.packageName
}

fun Context.launchPackage(pkg: String) {
    val i = launchIntentFor(pkg) ?: return
    getSharedPreferences("launcher", Context.MODE_PRIVATE).recordRecent(pkg)
    startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun Context.launch(item: AppItem) {
    val pkg = resolvePackage(item)
    if (pkg != null) launchPackage(pkg) else installApp(item)
}

fun Context.installApp(item: AppItem) {
    val pkg = item.packages.firstOrNull() ?: return
    val tries = listOf(
        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")),
    )
    for (t in tries) try { startActivity(t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
    Toast.makeText(this, "${item.title} не найден. Установите через Downloader", Toast.LENGTH_LONG).show()
}

fun Context.openSettings() {
    val tries = listOf(Intent(android.provider.Settings.ACTION_SETTINGS), Intent(android.provider.Settings.ACTION_APPLICATION_SETTINGS))
    for (t in tries) try { startActivity(t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
    Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_LONG).show()
}

fun Context.appInfo(pkg: String) {
    try {
        startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { Toast.makeText(this, "Не удалось открыть сведения о приложении", Toast.LENGTH_LONG).show() }
}

fun Context.uninstall(pkg: String) {
    try {
        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { Toast.makeText(this, "Не удалось удалить приложение", Toast.LENGTH_LONG).show() }
}

fun Context.isSystemApp(pkg: String): Boolean = try {
    (packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) != 0
} catch (e: Exception) { false }

// ---------- сеть / VPN ----------
/** РЕАЛЬНОЕ состояние: есть ли сеть с транспортом VPN. Без имитации. */
fun Context.isVpnActive(): Boolean {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    @Suppress("DEPRECATION")
    return cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
}

/** 0 — нет сети, 1 — Wi-Fi/прочее, 2 — Ethernet. */
fun Context.networkKind(): Int {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return 0
    return when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 2
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 1
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> 1
        else -> 0
    }
}

/** Публичного API у Happ нет: по нажатию открывается Happ, статус кнопки — реальный. */
const val HAPP_ACTION: String = ""

fun Context.toggleVpn() {
    val pkg = resolvePackage(APPS[1])
    if (HAPP_ACTION.isNotBlank() && pkg != null) {
        try { sendBroadcast(Intent(HAPP_ACTION).setPackage(pkg)); return } catch (_: Exception) {}
    }
    launch(APPS[1])
}

// ---------- ТВ-входы (HDMI / AV) ----------
data class TvInput(val id: String, val title: String)

fun Context.tvInputs(): List<TvInput> = try {
    val tm = getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
    tm.tvInputList.filter { it.isPassthroughInput }.map {
        val custom = it.loadCustomLabel(this)?.toString().orEmpty()
        TvInput(it.id, custom.ifBlank { it.loadLabel(this).toString() })
    }
} catch (e: Exception) { emptyList() }

fun Context.openInput(i: TvInput) {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(i.id)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { Toast.makeText(this, "Не удалось переключить вход", Toast.LENGTH_LONG).show() }
}

// ---------- ряд приложений на главном (порядок хранится в prefs) ----------
fun defaultRow(): List<String> = APPS.map { "d:" + it.title }

fun SharedPreferences.loadRow(): List<String> {
    val raw = getString("row", null)
    if (raw != null) return raw.split(",").filter { it.isNotBlank() }
    val custom = (getString("custom", "") ?: "").split(",").filter { it.isNotBlank() }  // миграция со старой версии
    return defaultRow() + custom.map { "c:$it" }
}

fun SharedPreferences.saveRow(list: List<String>) { edit().putString("row", list.joinToString(",")).apply() }

fun List<String>.moved(key: String, delta: Int): List<String> {
    val i = indexOf(key)
    if (i < 0) return this
    val j = (i + delta).coerceIn(0, size - 1)
    if (i == j) return this
    val m = toMutableList()
    m.removeAt(i)
    m.add(j, key)
    return m
}

// ---------- недавние приложения ----------
fun SharedPreferences.loadRecent(): List<String> = (getString("recent", "") ?: "").split(",").filter { it.isNotBlank() }

fun SharedPreferences.recordRecent(pkg: String) {
    val l = (listOf(pkg) + loadRecent().filter { it != pkg }).take(10)
    edit().putString("recent", l.joinToString(",")).apply()
}

// ---------- фильмы ----------
data class Film(val id: Long, val title: String, val poster: String, val year: String, val rating: String, val series: Boolean)
data class FilmInfo(val description: String, val genres: String, val countries: String, val length: String, val trailer: String?)

fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)

fun JSONObject.names(k: String, f: String): String {
    val a = optJSONArray(k) ?: return ""
    return (0 until a.length()).mapNotNull { a.optJSONObject(it)?.optString(f)?.takeIf { s -> s.isNotBlank() } }.joinToString(", ")
}

fun parseFilms(txt: String, key: String, forceSeries: Boolean?): List<Film> = try {
    val arr = JSONObject(txt).optJSONArray(key) ?: JSONArray()
    (0 until arr.length()).mapNotNull { i ->
        val o = arr.getJSONObject(i)
        val id = if (o.has("kinopoiskId")) o.optLong("kinopoiskId") else o.optLong("filmId")
        val name = o.str("nameRu").ifBlank { o.str("nameEn").ifBlank { o.str("nameOriginal") } }
        if (id == 0L || name.isBlank()) null
        else Film(id, name, o.str("posterUrlPreview"), o.str("year"),
            o.str("ratingKinopoisk").ifBlank { o.str("rating") },
            forceSeries ?: o.str("type").contains("SERIES"))
    }
} catch (e: Exception) { emptyList() }

fun SharedPreferences.loadFilms(key: String): List<Film> = try {
    val a = JSONArray(getString(key, "[]"))
    (0 until a.length()).map {
        val o = a.getJSONObject(it)
        Film(o.getLong("id"), o.getString("t"), o.optString("p"), o.optString("y"), o.optString("r"), o.optBoolean("s"))
    }
} catch (e: Exception) { emptyList() }

fun SharedPreferences.saveFilms(key: String, list: List<Film>) {
    val a = JSONArray()
    list.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("p", it.poster).put("y", it.year).put("r", it.rating).put("s", it.series)) }
    edit().putString(key, a.toString()).apply()
}

suspend fun kp(path: String): String? = withContext(Dispatchers.IO) {
    try {
        val c = URL("https://kinopoiskapiunofficial.tech$path").openConnection() as HttpURLConnection
        c.setRequestProperty("X-API-KEY", Config.kpKey)
        c.connectTimeout = 8000; c.readTimeout = 8000
        if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
    } catch (e: Exception) { null }
}

/** Описание, жанры, страны и трейлер для карточки фильма. */
suspend fun loadInfo(id: Long): FilmInfo? {
    val txt = kp("/api/v2.2/films/$id") ?: return null
    val o = try { JSONObject(txt) } catch (e: Exception) { return null }
    val trailer = kp("/api/v2.2/films/$id/videos")?.let { v ->
        try {
            val a = JSONObject(v).optJSONArray("items") ?: JSONArray()
            val list = (0 until a.length()).mapNotNull { a.optJSONObject(it) }
            (list.firstOrNull { it.optString("site") == "YOUTUBE" } ?: list.firstOrNull())?.optString("url")?.takeIf { it.isNotBlank() }
        } catch (e: Exception) { null }
    }
    val len = o.optInt("filmLength", 0)
    return FilmInfo(
        description = o.str("description").ifBlank { o.str("shortDescription") },
        genres = o.names("genres", "genre"),
        countries = o.names("countries", "country"),
        length = if (len > 0) "$len мин" else "",
        trailer = trailer
    )
}

// ---------- разделы ----------
enum class Section(val label: String, val icon: Int) {
    Home("Главная", R.drawable.ic_home), Apps("Приложения", R.drawable.ic_apps),
    Movies("Фильмы", R.drawable.ic_movie), Series("Сериалы", R.drawable.ic_tv),
    Favs("Избранное", R.drawable.ic_star), Inputs("Входы", R.drawable.ic_input)
}

const val NEED_KEY = "Для каталога нужен бесплатный ключ API с kinopoiskapiunofficial.tech. Нажмите шестерёнку вверху и вставьте ключ в «Настройки лаунчера»."

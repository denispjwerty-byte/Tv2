package com.sharks.launcher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val cmd = mutableStateOf<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cmd.value = intent
        setContent { Launcher(cmd.value) }
    }

    /** Кнопка «Домой» возвращает на главный экран; extras (section, wallpaper, settings…) нужны для скриншотов через adb. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        cmd.value = intent
    }
}

fun initialWallpaper(prefs: SharedPreferences): Wallpaper =
    Wallpaper.values().firstOrNull { it.name == prefs.getString("wallpaper", "") } ?: Wallpaper.Waves

// ---------- главный экран ----------
@Composable
fun Launcher(startIntent: Intent? = null) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    var vpn by remember { mutableStateOf(ctx.isVpnActive()) }
    var section by remember { mutableStateOf(Section.Home) }
    var query by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf<Film?>(null) }
    var picker by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableStateOf(0) }
    var wallpaper by remember { mutableStateOf(initialWallpaper(prefs).also { Theme.accent = it.accent }) }
    var apiKey by remember {
        mutableStateOf((prefs.getString("kp_key", "") ?: "").ifBlank { BuildConfig.KP_API_KEY }.also { Config.kpKey = it })
    }
    var favs by remember { mutableStateOf(prefs.loadFilms("favs")) }
    var history by remember { mutableStateOf(prefs.loadFilms("hist")) }
    var row by remember { mutableStateOf(prefs.loadRow()) }
    var recent by remember { mutableStateOf(prefs.loadRecent()) }
    var popular by remember { mutableStateOf<List<Film>?>(prefs.loadFilms("c_pop").takeIf { it.isNotEmpty() }) }
    var movies by remember { mutableStateOf<List<Film>?>(prefs.loadFilms("c_mov").takeIf { it.isNotEmpty() }) }
    var series by remember { mutableStateOf<List<Film>?>(prefs.loadFilms("c_ser").takeIf { it.isNotEmpty() }) }
    var found by remember { mutableStateOf<List<Film>>(emptyList()) }
    val hasKey = apiKey.isNotBlank()

    fun pickWallpaper(w: Wallpaper) {
        wallpaper = w
        Theme.accent = w.accent
        prefs.edit().putString("wallpaper", w.name).apply()
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) query = t
    }
    fun voice() {
        try {
            speech.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Что ищем?")
            )
        } catch (e: Exception) { Toast.makeText(ctx, "Голосовой поиск недоступен на этом устройстве", Toast.LENGTH_LONG).show() }
    }

    LaunchedEffect(startIntent) {
        val i = startIntent ?: return@LaunchedEffect
        var any = false
        i.getStringExtra("wallpaper")?.let { n ->
            Wallpaper.values().firstOrNull { it.name.equals(n, true) }?.let { pickWallpaper(it) }; any = true
        }
        i.getStringExtra("section")?.let { n ->
            Section.values().firstOrNull { it.name.equals(n, true) }?.let { section = it }; any = true
        }
        i.getStringExtra("query")?.let { query = it; any = true }
        if (i.hasExtra("settings")) { settings = i.getBooleanExtra("settings", false); any = true }
        if (i.hasExtra("picker")) { picker = i.getBooleanExtra("picker", false); any = true }
        if (!any && i.hasCategory(Intent.CATEGORY_HOME)) {
            detail = null; picker = false; settings = false; menu = null; query = ""; section = Section.Home
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            vpn = ctx.isVpnActive()
            val r = prefs.loadRecent()
            if (r != recent) recent = r
            delay(1000)
        }
    }
    LaunchedEffect(hasKey, tick) {
        if (hasKey) while (true) {
            val r = kp("/api/v2.2/films/collections?type=TOP_POPULAR_ALL&page=1")?.let { parseFilms(it, "items", null) }
            if (r != null && r.isNotEmpty()) { popular = r; prefs.saveFilms("c_pop", r) } else if (popular == null) popular = emptyList()
            delay(30 * 60 * 1000L)
        }
    }
    LaunchedEffect(section, hasKey, tick) {
        if (!hasKey) return@LaunchedEffect
        if (section == Section.Movies) {
            val r = kp("/api/v2.2/films/collections?type=TOP_POPULAR_MOVIES&page=1")?.let { parseFilms(it, "items", false) }
            if (r != null && r.isNotEmpty()) { movies = r; prefs.saveFilms("c_mov", r) } else if (movies == null) movies = emptyList()
        }
        if (section == Section.Series) {
            val r = kp("/api/v2.2/films/collections?type=TOP_250_TV_SHOWS&page=1")?.let { parseFilms(it, "items", true) }
            if (r != null && r.isNotEmpty()) { series = r; prefs.saveFilms("c_ser", r) } else if (series == null) series = emptyList()
        }
    }
    LaunchedEffect(query, hasKey) {
        if (query.length >= 2 && hasKey) {
            delay(500)
            found = kp("/api/v2.1/films/search-by-keyword?keyword=${Uri.encode(query)}&page=1")?.let { parseFilms(it, "films", null) } ?: emptyList()
        } else found = emptyList()
    }

    fun toggleFav(f: Film) {
        favs = if (favs.any { it.id == f.id }) favs.filter { it.id != f.id } else listOf(f) + favs
        prefs.saveFilms("favs", favs)
    }
    fun watch(f: Film) {
        history = (listOf(f) + history.filter { it.id != f.id }).take(20)
        prefs.saveFilms("hist", history)
        val url = "https://www.kinopoisk.ru/${if (f.series) "series" else "film"}/${f.id}/"
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(ctx, "Не удалось открыть КиноПоиск", Toast.LENGTH_LONG).show() }
    }
    fun addApp(pkg: String) {
        val key = "c:$pkg"
        if (key !in row) { row = row + key; prefs.saveRow(row) }
        picker = false
    }

    BackHandler(enabled = true) {
        when {
            menu != null -> menu = null
            settings -> { settings = false; tick++ }
            detail != null -> detail = null
            picker -> picker = false
            query.isNotEmpty() -> query = ""
            section != Section.Home -> section = Section.Home
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        WallpaperBackground(wallpaper)
        Row(Modifier.fillMaxSize()) {
            Sidebar(section) { section = it; query = "" }
            Column(Modifier.weight(1f).fillMaxHeight().padding(start = 16.dp, end = 48.dp, top = 96.dp)) {
                SearchBar(query, { query = it }) { voice() }
                Spacer(Modifier.height(20.dp))
                when {
                    query.isNotEmpty() -> SearchResults(query, found, hasKey, { detail = it }, { ctx.launchPackage(it) })
                    section == Section.Home -> Column(Modifier.verticalScroll(rememberScrollState())) {
                        SectionTitle("Приложения")
                        AppsRow(row, { menu = it }) { picker = true }
                        val recentPk = remember(recent) { recent.filter { ctx.launchIntentFor(it) != null } }
                        if (recentPk.isNotEmpty()) {
                            SectionTitle("Недавние приложения")
                            RecentRow(recentPk)
                        }
                        if (history.isNotEmpty()) {
                            SectionTitle("Продолжить просмотр")
                            PosterRow(history, { detail = it }, { f -> history = history.filter { it.id != f.id }; prefs.saveFilms("hist", history) })
                        }
                        SectionTitle("Популярное")
                        when {
                            !hasKey -> Hint(NEED_KEY)
                            popular == null -> Hint("Загрузка…")
                            popular!!.isEmpty() -> Retry("Не удалось загрузить. Проверьте интернет и ключ.") { tick++ }
                            else -> PosterRow(popular!!, { detail = it }, null)
                        }
                        if (favs.isNotEmpty()) {
                            SectionTitle("Избранное")
                            PosterRow(favs, { detail = it }, null)
                        }
                        Spacer(Modifier.height(40.dp))
                    }
                    section == Section.Apps -> AllApps("Все приложения") { ctx.launchPackage(it) }
                    section == Section.Movies -> FilmGrid(movies, hasKey, { tick++ }) { detail = it }
                    section == Section.Series -> FilmGrid(series, hasKey, { tick++ }) { detail = it }
                    section == Section.Favs ->
                        if (favs.isEmpty()) Hint("Пока пусто. Откройте фильм и нажмите «В избранное».") else FilmGrid(favs, true, {}) { detail = it }
                    else -> InputsScreen()
                }
            }
        }
        Row(
            Modifier.align(Alignment.TopEnd).padding(top = 28.dp, end = 48.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            StatusBar()
            SettingsButton { settings = true }
            VpnButton(vpn) { ctx.toggleVpn() }
        }
        if (picker) Box(Modifier.fillMaxSize().background(Color(0xF2000000)).padding(40.dp)) {
            AllApps("Выберите приложение для добавления") { addApp(it) }
        }
        detail?.let { f ->
            DetailScreen(f, favs.any { it.id == f.id }, { watch(f) }, { toggleFav(f) }, { detail = null })
        }
        if (settings) SettingsScreen(
            wallpaper, { pickWallpaper(it) },
            apiKey, { apiKey = it; Config.kpKey = it; prefs.edit().putString("kp_key", it).apply() },
            { row = defaultRow(); prefs.saveRow(row); Toast.makeText(ctx, "Ряд приложений сброшен", Toast.LENGTH_SHORT).show() },
            { ctx.openSettings() },
            { settings = false; tick++ }
        )
        menu?.let { key -> AppMenu(key, row, { row = it; prefs.saveRow(it) }, { menu = null }) }
    }
}

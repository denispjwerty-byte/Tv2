# SHARKS TRAID VIDEO MAX — лаунчер для Android TV

## Ключ КиноПоиска (без него каталог пуст)
Любой из способов:
- в лаунчере: шестерёнка → «Настройки лаунчера» → «Ключ API КиноПоиска»;
- локально: строка `KP_API_KEY=...` в `local.properties` (файл в .gitignore);
- CI: секрет репозитория `KP_API_KEY` (GitHub → Settings → Secrets → Actions).

## Подпись
По умолчанию используется `app/sharks.jks` (как раньше). Для своего ключа задайте переменные
`KEYSTORE_FILE`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Если репозиторий публичный —
считайте текущий ключ скомпрометированным и замените его.

## Настоящие скриншоты
`./tools/screenshots.sh 192.168.1.50:5555` — пройдёт по всем обоям и разделам и сохранит PNG в `docs/real/`.
Лаунчер принимает extras: `--es wallpaper Waves|Ocean|Shark|Sunset|Neon|Emerald|Black`,
`--es section Home|Apps|Movies|Series|Favs|Inputs`, `--ez settings true`, `--ez picker true`, `--es query текст`.

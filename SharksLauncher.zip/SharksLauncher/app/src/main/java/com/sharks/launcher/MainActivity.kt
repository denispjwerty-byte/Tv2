package com.sharks.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay

/** packages — известные имена пакетов; labels — части названия (поиск среди установленных, без учёта регистра). */
data class AppItem(val title: String, val packages: List<String>, val labels: List<String>, val accent: Color)

val HAPP_PACKAGES = listOf("com.happproxy", "com.happproxy.android", "com.happ.android")

val APPS = listOf(
    AppItem("YouTube", listOf("com.google.android.youtube.tv", "com.google.android.youtube"), listOf("youtube"), Color(0xFFFF0033)),
    AppItem("Happ VPN", HAPP_PACKAGES, listOf("happ"), Color(0xFF19B5FE)),
    AppItem("Google Chrome", listOf("com.android.chrome", "com.chrome.beta"), listOf("chrome"), Color(0xFF4285F4)),
    AppItem("Play Маркет", listOf("com.android.vending"), listOf("play маркет", "play store", "google play"), Color(0xFF34A853)),
    AppItem("Downloader", listOf("com.esaba.downloader"), listOf("downloader"), Color(0xFFFF9800)),
    AppItem("Файлы", listOf("com.mixplorer", "com.google.android.apps.nbu.files", "com.android.documentsui",
        "com.google.android.documentsui", "com.android.fileexplorer", "com.droidlogic.FileBrower", "com.softwinner.TvdFileManager"),
        listOf("file", "файл", "explorer", "проводник", "manager", "менеджер"), Color(0xFF9C6BFF)),
    AppItem("Все приложения", emptyList(), emptyList(), Color(0xFF555555)),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Launcher() }
    }
}

fun Context.launchIntentFor(pkg: String): Intent? =
    packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: packageManager.getLaunchIntentForPackage(pkg)

/** Все приложения, которые можно запустить (обычные и для ТВ), без нашего лаунчера. */
fun Context.allLaunchable(): List<ResolveInfo> {
    val pm = packageManager
    val a = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
    val b = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
    return (a + b).distinctBy { it.activityInfo.packageName }
        .filter { it.activityInfo.packageName != packageName }
        .sortedBy { it.loadLabel(pm).toString().lowercase() }
}

/** Сначала известные пакеты, потом поиск по названию среди установленных. */
fun Context.resolvePackage(item: AppItem): String? {
    item.packages.firstOrNull { launchIntentFor(it) != null }?.let { return it }
    if (item.labels.isEmpty()) return null
    return allLaunchable().firstOrNull { ri ->
        val l = ri.loadLabel(packageManager).toString().lowercase()
        item.labels.any { l.contains(it) }
    }?.activityInfo?.packageName
}

/** Системные настройки приставки (оттуда можно удалять приложения и выбирать главный экран). */
fun Context.openSettings() {
    val tries = listOf(Intent(android.provider.Settings.ACTION_SETTINGS), Intent(android.provider.Settings.ACTION_APPLICATION_SETTINGS))
    for (t in tries) try { startActivity(t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
    Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_LONG).show()
}

fun Context.launchPackage(pkg: String) {
    launchIntentFor(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { startActivity(it) }
}

fun Context.launch(item: AppItem) {
    val pkg = resolvePackage(item)
    if (pkg != null) launchPackage(pkg) else installApp(item)
}

fun Context.installApp(item: AppItem) {
    val pkg = item.packages.firstOrNull() ?: return
    val tries = listOf(
        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")),
    )
    for (t in tries) try { startActivity(t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
    Toast.makeText(this, "${item.title} не найден. Установите через Downloader", Toast.LENGTH_LONG).show()
}

/** РЕАЛЬНОЕ состояние: есть ли сеть с транспортом VPN. Без имитации. */
fun Context.isVpnActive(): Boolean {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    @Suppress("DEPRECATION")
    return cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
}

/** Публичного API у Happ нет: по нажатию открывается Happ, статус кнопки — реальный. */
const val HAPP_ACTION: String = ""

fun Context.toggleVpn() {
    val pkg = resolvePackage(APPS[1])
    if (HAPP_ACTION.isNotBlank() && pkg != null) {
        try { sendBroadcast(Intent(HAPP_ACTION).setPackage(pkg)); return } catch (_: Exception) {}
    }
    launch(APPS[1])
}

@Composable
fun Launcher() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    var vpn by remember { mutableStateOf(ctx.isVpnActive()) }
    var showAll by remember { mutableStateOf(false) }
    val startIndex = remember { prefs.getInt("last", 0).coerceIn(0, APPS.lastIndex) }
    val requesters = remember { List(APPS.size) { FocusRequester() } }

    BackHandler(enabled = true) { if (showAll) showAll = false }
    LaunchedEffect(showAll) { if (!showAll) runCatching { requesters[startIndex].requestFocus() } }
    LaunchedEffect(Unit) { while (true) { vpn = ctx.isVpnActive(); delay(1000) } }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (showAll) {
            AllApps()
        } else {
            Row(Modifier.align(Alignment.TopEnd).padding(top = 40.dp, end = 56.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                SettingsButton { ctx.openSettings() }
                VpnButton(vpn, Modifier) { ctx.toggleVpn() }
            }
            Column(Modifier.align(Alignment.CenterStart).padding(start = 56.dp)) {
                Text("SHARKS TRAID", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
                Text("VIDEO MAX", color = Color(0x99FFFFFF), fontSize = 14.sp, letterSpacing = 4.sp)
                Spacer(Modifier.height(48.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 12.dp, horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    APPS.forEachIndexed { idx, item ->
                        val icon = remember(item) {
                            ctx.resolvePackage(item)?.let { runCatching { ctx.packageManager.getApplicationIcon(it).toBitmap(256, 256).asImageBitmap() }.getOrNull() }
                        }
                        Tile(item.title, icon, item.accent, if (item.packages.isEmpty()) "▦" else item.title.first().toString(), requesters[idx]) {
                            prefs.edit().putInt("last", idx).apply()
                            when {
                                item.packages.isEmpty() -> showAll = true
                                else -> ctx.launch(item)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AllApps() {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    val apps = remember {
        ctx.allLaunchable().map { ri ->
            Triple(ri.activityInfo.packageName, ri.loadLabel(pm).toString(),
                runCatching { ri.loadIcon(pm).toBitmap(160, 160).asImageBitmap() }.getOrNull())
        }
    }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 56.dp, vertical = 40.dp)) {
        Text("Все приложения", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        LazyVerticalGrid(columns = GridCells.Adaptive(150.dp), horizontalArrangement = Arrangement.spacedBy(20.dp), verticalArrangement = Arrangement.spacedBy(24.dp)) {
            items(apps.size) { i ->
                val (pkg, label, icon) = apps[i]
                Tile(label, icon, Color(0xFF444444), label.take(1).uppercase(), if (i == 0) first else remember { FocusRequester() }) { ctx.launchPackage(pkg) }
            }
        }
    }
}

@Composable
fun Tile(title: String, icon: ImageBitmap?, accent: Color, letter: String, requester: FocusRequester, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.12f else 1f, tween(160), label = "s")
    val border by animateColorAsState(if (focused) Color.White else Color(0x22FFFFFF), tween(160), label = "b")
    val bg by animateColorAsState(if (focused) Color(0xFF1C1C1E) else Color(0xFF0E0E10), tween(160), label = "bg")
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(140.dp).scale(scale)) {
        Box(
            Modifier.size(140.dp)
                .focusRequester(requester)
                .onFocusChanged { focused = it.isFocused }
                .background(bg, RoundedCornerShape(28.dp))
                .border(if (focused) 4.dp else 1.dp, border, RoundedCornerShape(28.dp))
                .clickable(onClick = onClick)
                .focusable(),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) Image(icon, title, Modifier.size(88.dp))
            else Box(Modifier.size(88.dp).background(accent, RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
                Text(letter, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(title, color = if (focused) Color.White else Color(0x99FFFFFF), fontSize = 15.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
fun VpnButton(on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val color by animateColorAsState(if (on) Color(0xFF2ECC71) else Color(0xFF8A8A8E), tween(250), label = "c")
    val scale by animateFloatAsState(if (focused) 1.1f else 1f, tween(160), label = "s")
    Row(
        modifier.scale(scale)
            .onFocusChanged { focused = it.isFocused }
            .background(if (focused) Color(0xFF1C1C1E) else Color(0xFF0E0E10), RoundedCornerShape(50))
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else color.copy(alpha = .5f), RoundedCornerShape(50))
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 28.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(12.dp).background(color, RoundedCornerShape(50)))
        Spacer(Modifier.width(12.dp))
        Text("VPN  " + if (on) "ВКЛ" else "ВЫКЛ", color = color, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SettingsButton(onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.1f else 1f, tween(160), label = "s")
    Box(
        Modifier.scale(scale)
            .onFocusChanged { focused = it.isFocused }
            .background(if (focused) Color(0xFF1C1C1E) else Color(0xFF0E0E10), RoundedCornerShape(50))
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else Color(0x33FFFFFF), RoundedCornerShape(50))
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 28.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("Настройки", color = if (focused) Color.White else Color(0xBBFFFFFF), fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

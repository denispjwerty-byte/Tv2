package com.sharks.launcher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ResolveInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** ВСТАВЬТЕ СЮДА бесплатный ключ с kinopoiskapiunofficial.tech (без него каталог КиноПоиска не загрузится). */
const val KP_API_KEY = ""

val Red = Color(0xFFE50914)
val Glass = Color(0x26FFFFFF)
val GlassBorder = Color(0x22FFFFFF)

// ---------- приложения ----------
data class AppItem(val title: String, val packages: List<String>, val labels: List<String>, val accent: Color)

val HAPP_PACKAGES = listOf("com.happproxy", "com.happproxy.android", "com.happ.android")

val APPS = listOf(
    AppItem("YouTube", listOf("com.google.android.youtube.tv", "com.google.android.youtube"), listOf("youtube"), Color(0xFFFF0033)),
    AppItem("Happ", HAPP_PACKAGES, listOf("happ"), Color(0xFF19B5FE)),
    AppItem("Google Play", listOf("com.android.vending"), listOf("play маркет", "play store", "google play"), Color(0xFF34A853)),
    AppItem("КиноПоиск", listOf("ru.kinopoisk", "ru.kinopoisk.tv"), listOf("кинопоиск", "kinopoisk"), Color(0xFFFF6600)),
    AppItem("Downloader", listOf("com.esaba.downloader"), listOf("downloader"), Color(0xFFFF9800)),
    AppItem("Файловый менеджер", listOf("com.google.android.apps.nbu.files", "com.android.documentsui",
        "com.google.android.documentsui", "com.android.fileexplorer", "com.droidlogic.FileBrower", "com.softwinner.TvdFileManager"),
        listOf("файловый менеджер", "file manager", "files", "файлы"), Color(0xFF9C6BFF)),
    AppItem("CX Проводник", listOf("com.cxinventor.file.explorer"), listOf("cx "), Color(0xFF2196F3)),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Launcher() }
    }
}

fun Context.launchIntentFor(pkg: String): Intent? =
    packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: packageManager.getLaunchIntentForPackage(pkg)

fun Context.allLaunchable(): List<ResolveInfo> {
    val pm = packageManager
    val a = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
    val b = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
    return (a + b).distinctBy { it.activityInfo.packageName }
        .filter { it.activityInfo.packageName != packageName }
        .sortedBy { it.loadLabel(pm).toString().lowercase() }
}

fun Context.resolvePackage(item: AppItem): String? {
    item.packages.firstOrNull { launchIntentFor(it) != null }?.let { return it }
    if (item.labels.isEmpty()) return null
    return allLaunchable().firstOrNull { ri ->
        val l = ri.loadLabel(packageManager).toString().lowercase()
        item.labels.any { l.contains(it) }
    }?.activityInfo?.packageName
}

fun Context.launchPackage(pkg: String) {
    launchIntentFor(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { startActivity(it) }
}

fun Context.launch(item: AppItem) {
    val pkg = resolvePackage(item)
    if (pkg != null) launchPackage(pkg) else installApp(item)
}

fun Context.installApp(item: AppItem) {
    val pkg = item.packages.firstOrNull() ?: return
    val tries = listOf(
        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")),
    )
    for (t in tries) try { startActivity(t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
    Toast.makeText(this, "${item.title} не найден. Установите через Downloader", Toast.LENGTH_LONG).show()
}

fun Context.openSettings() {
    val tries = listOf(Intent(android.provider.Settings.ACTION_SETTINGS), Intent(android.provider.Settings.ACTION_APPLICATION_SETTINGS))
    for (t in tries) try { startActivity(t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
    Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_LONG).show()
}

/** РЕАЛЬНОЕ состояние: есть ли сеть с транспортом VPN. Без имитации. */
fun Context.isVpnActive(): Boolean {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    @Suppress("DEPRECATION")
    return cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
}

/** Публичного API у Happ нет: по нажатию открывается Happ, статус кнопки — реальный. */
const val HAPP_ACTION: String = ""

fun Context.toggleVpn() {
    val pkg = resolvePackage(APPS[1])
    if (HAPP_ACTION.isNotBlank() && pkg != null) {
        try { sendBroadcast(Intent(HAPP_ACTION).setPackage(pkg)); return } catch (_: Exception) {}
    }
    launch(APPS[1])
}

// ---------- фильмы ----------
data class Film(val id: Long, val title: String, val poster: String, val year: String, val rating: String, val series: Boolean)

fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)

fun parseFilms(txt: String, key: String, forceSeries: Boolean?): List<Film> = try {
    val arr = JSONObject(txt).optJSONArray(key) ?: JSONArray()
    (0 until arr.length()).mapNotNull { i ->
        val o = arr.getJSONObject(i)
        val id = if (o.has("kinopoiskId")) o.optLong("kinopoiskId") else o.optLong("filmId")
        val name = o.str("nameRu").ifBlank { o.str("nameEn").ifBlank { o.str("nameOriginal") } }
        if (id == 0L || name.isBlank()) null
        else Film(id, name, o.str("posterUrlPreview"), o.str("year"),
            o.str("ratingKinopoisk").ifBlank { o.str("rating") },
            forceSeries ?: o.str("type").contains("SERIES"))
    }
} catch (e: Exception) { emptyList() }

fun SharedPreferences.loadFilms(key: String): List<Film> = try {
    val a = JSONArray(getString(key, "[]"))
    (0 until a.length()).map {
        val o = a.getJSONObject(it)
        Film(o.getLong("id"), o.getString("t"), o.optString("p"), o.optString("y"), o.optString("r"), o.optBoolean("s"))
    }
} catch (e: Exception) { emptyList() }

fun SharedPreferences.saveFilms(key: String, list: List<Film>) {
    val a = JSONArray()
    list.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("p", it.poster).put("y", it.year).put("r", it.rating).put("s", it.series)) }
    edit().putString(key, a.toString()).apply()
}

suspend fun kp(path: String): String? = withContext(Dispatchers.IO) {
    try {
        val c = URL("https://kinopoiskapiunofficial.tech$path").openConnection() as HttpURLConnection
        c.setRequestProperty("X-API-KEY", KP_API_KEY)
        c.connectTimeout = 8000; c.readTimeout = 8000
        if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
    } catch (e: Exception) { null }
}

enum class Section(val label: String, val icon: Int) {
    Home("Главная", R.drawable.ic_home), Apps("Приложения", R.drawable.ic_apps),
    Movies("Фильмы", R.drawable.ic_movie), Series("Сериалы", R.drawable.ic_tv), Favs("Избранное", R.drawable.ic_star)
}

const val NEED_KEY = "Для каталога нужен бесплатный ключ API с kinopoiskapiunofficial.tech. Вставьте его в строку KP_API_KEY в файле MainActivity.kt."

// ---------- главный экран ----------
@Composable
fun Launcher() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    var vpn by remember { mutableStateOf(ctx.isVpnActive()) }
    var section by remember { mutableStateOf(Section.Home) }
    var query by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf<Film?>(null) }
    var picker by remember { mutableStateOf(false) }
    var favs by remember { mutableStateOf(prefs.loadFilms("favs")) }
    var history by remember { mutableStateOf(prefs.loadFilms("hist")) }
    var custom by remember { mutableStateOf((prefs.getString("custom", "") ?: "").split(",").filter { it.isNotBlank() }) }
    var popular by remember { mutableStateOf<List<Film>?>(null) }
    var movies by remember { mutableStateOf<List<Film>?>(null) }
    var series by remember { mutableStateOf<List<Film>?>(null) }
    var found by remember { mutableStateOf<List<Film>>(emptyList()) }
    val hasKey = KP_API_KEY.isNotBlank()

    LaunchedEffect(Unit) { while (true) { vpn = ctx.isVpnActive(); delay(1000) } }
    LaunchedEffect(Unit) {
        if (hasKey) while (true) {
            kp("/api/v2.2/films/collections?type=TOP_POPULAR_ALL&page=1")?.let { popular = parseFilms(it, "items", null) }
            delay(30 * 60 * 1000L)
        }
    }
    LaunchedEffect(section) {
        if (!hasKey) return@LaunchedEffect
        if (section == Section.Movies && movies == null)
            kp("/api/v2.2/films/collections?type=TOP_POPULAR_MOVIES&page=1")?.let { movies = parseFilms(it, "items", false) }
        if (section == Section.Series && series == null)
            kp("/api/v2.2/films/collections?type=TOP_250_TV_SHOWS&page=1")?.let { series = parseFilms(it, "items", true) }
    }
    LaunchedEffect(query) {
        if (query.length >= 2 && hasKey) {
            delay(500)
            found = kp("/api/v2.1/films/search-by-keyword?keyword=${Uri.encode(query)}&page=1")?.let { parseFilms(it, "films", null) } ?: emptyList()
        } else found = emptyList()
    }

    fun toggleFav(f: Film) {
        favs = if (favs.any { it.id == f.id }) favs.filter { it.id != f.id } else listOf(f) + favs
        prefs.saveFilms("favs", favs)
    }
    fun watch(f: Film) {
        history = (listOf(f) + history.filter { it.id != f.id }).take(20)
        prefs.saveFilms("hist", history)
        val url = "https://www.kinopoisk.ru/${if (f.series) "series" else "film"}/${f.id}/"
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(ctx, "Не удалось открыть КиноПоиск", Toast.LENGTH_LONG).show() }
    }
    fun addApp(pkg: String) {
        if (pkg !in custom) { custom = custom + pkg; prefs.edit().putString("custom", custom.joinToString(",")).apply() }
        picker = false
    }

    BackHandler(enabled = true) {
        when {
            detail != null -> detail = null
            picker -> picker = false
            query.isNotEmpty() -> query = ""
            section != Section.Home -> section = Section.Home
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        RedWaves()
        Row(Modifier.fillMaxSize()) {
            Sidebar(section) { section = it; query = "" }
            Column(Modifier.weight(1f).fillMaxHeight().padding(start = 16.dp, end = 48.dp, top = 96.dp)) {
                SearchBar(query) { query = it }
                Spacer(Modifier.height(20.dp))
                when {
                    query.isNotEmpty() -> SearchResults(query, found, hasKey, { detail = it }, { ctx.launchPackage(it) })
                    section == Section.Home -> Column(Modifier.verticalScroll(rememberScrollState())) {
                        SectionTitle("Приложения")
                        AppsRow(custom, { custom = custom - it; prefs.edit().putString("custom", custom.joinToString(",")).apply() }) { picker = true }
                        if (history.isNotEmpty()) {
                            SectionTitle("Продолжить просмотр")
                            PosterRow(history, { detail = it }, { f -> history = history.filter { it.id != f.id }; prefs.saveFilms("hist", history) })
                        }
                        SectionTitle("Популярное")
                        when {
                            !hasKey -> Hint(NEED_KEY)
                            popular == null -> Hint("Загрузка…")
                            popular!!.isEmpty() -> Hint("Не удалось загрузить. Проверьте интернет и ключ.")
                            else -> PosterRow(popular!!, { detail = it }, null)
                        }
                        if (favs.isNotEmpty()) {
                            SectionTitle("Избранное")
                            PosterRow(favs, { detail = it }, null)
                        }
                        Spacer(Modifier.height(40.dp))
                    }
                    section == Section.Apps -> AllApps("Все приложения") { ctx.launchPackage(it) }
                    section == Section.Movies -> FilmGrid(movies, hasKey) { detail = it }
                    section == Section.Series -> FilmGrid(series, hasKey) { detail = it }
                    else -> if (favs.isEmpty()) Hint("Пока пусто. Откройте фильм и нажмите «В избранное».") else FilmGrid(favs, true) { detail = it }
                }
            }
        }
        Row(Modifier.align(Alignment.TopEnd).padding(top = 28.dp, end = 48.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            SettingsButton { ctx.openSettings() }
            VpnButton(vpn) { ctx.toggleVpn() }
        }
        if (picker) Box(Modifier.fillMaxSize().background(Color(0xF2000000)).padding(40.dp)) {
            AllApps("Выберите приложение для добавления") { addApp(it) }
        }
        detail?.let { f ->
            DetailScreen(f, favs.any { it.id == f.id }, { watch(f) }, { toggleFav(f) }, { detail = null })
        }
    }
}

@Composable
fun RedWaves() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.radialGradient(listOf(Color(0x66E50914), Color.Transparent), center = Offset(size.width * 0.75f, 0f), radius = size.width * 0.6f))
        drawRect(Brush.radialGradient(listOf(Color(0x44B00020), Color.Transparent), center = Offset(0f, size.height * 0.4f), radius = size.width * 0.4f))
        for (k in 0..3) {
            val p = Path().apply {
                moveTo(size.width * 0.2f, size.height * (0.6f + k * 0.04f))
                cubicTo(size.width * 0.5f, size.height * (0.15f + k * 0.05f), size.width * 0.7f, size.height * (0.95f - k * 0.05f), size.width, size.height * (0.3f + k * 0.04f))
            }
            drawPath(p, Red.copy(alpha = 0.28f - k * 0.05f), style = Stroke(width = 3f + k * 3f))
        }
    }
}

@Composable
fun SectionTitle(t: String) {
    Text(t, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 16.dp, bottom = 12.dp))
}

@Composable
fun Hint(t: String) {
    Text(t, color = Color(0xAAFFFFFF), fontSize = 17.sp, modifier = Modifier.padding(vertical = 8.dp).widthIn(max = 700.dp))
}

@Composable
fun Sidebar(current: Section, onSelect: (Section) -> Unit) {
    Column(Modifier.width(132.dp).fillMaxHeight().padding(top = 40.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Section.values().forEach { s ->
            var focused by remember { mutableStateOf(false) }
            val sel = s == current
            Column(
                Modifier.width(104.dp).height(92.dp)
                    .onFocusChanged { focused = it.isFocused; if (it.isFocused) onSelect(s) }
                    .background(if (sel) Brush.verticalGradient(listOf(Color(0xFFFF2A2A), Color(0xFF8E0010))) else SolidColor(Color.Transparent), RoundedCornerShape(20.dp))
                    .border(if (focused) 3.dp else 0.dp, if (focused) Color.White else Color.Transparent, RoundedCornerShape(20.dp))
                    .clickable { onSelect(s) }.focusable(),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Icon(painterResource(s.icon), s.label, Modifier.size(34.dp), tint = if (sel || focused) Color.White else Color(0xFFB0B0B0))
                Spacer(Modifier.height(6.dp))
                Text(s.label, color = if (sel || focused) Color.White else Color(0xFFB0B0B0), fontSize = 14.sp, maxLines = 1)
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun SearchBar(query: String, onChange: (String) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val kb = LocalSoftwareKeyboardController.current
    Row(
        Modifier.fillMaxWidth().height(60.dp)
            .background(Glass, RoundedCornerShape(30.dp))
            .border(if (focused) 3.dp else 1.dp, if (focused) Red else GlassBorder, RoundedCornerShape(30.dp))
            .padding(horizontal = 24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(painterResource(R.drawable.ic_search), null, Modifier.size(28.dp), tint = Color(0xFFCCCCCC))
        Spacer(Modifier.width(16.dp))
        BasicTextField(
            value = query, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 22.sp),
            cursorBrush = SolidColor(Red),
            modifier = Modifier.weight(1f)
                .onFocusChanged { focused = it.isFocused }
                .onPreviewKeyEvent { e ->
                    if (e.type == KeyEventType.KeyUp && (e.key == Key.DirectionCenter || e.key == Key.Enter)) { kb?.show(); true } else false
                },
            decorationBox = { inner ->
                if (query.isEmpty()) Text("Поиск приложений и контента…", color = Color(0x99FFFFFF), fontSize = 22.sp)
                inner()
            }
        )
    }
}

@Composable
fun SearchResults(query: String, films: List<Film>, hasKey: Boolean, onFilm: (Film) -> Unit, onApp: (String) -> Unit) {
    val ctx = LocalContext.current
    val apps = remember(query) {
        ctx.allLaunchable().filter { it.loadLabel(ctx.packageManager).toString().contains(query, ignoreCase = true) }
    }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        if (apps.isNotEmpty()) {
            SectionTitle("Приложения")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(8.dp)) {
                rowItems(apps) { ri ->
                    val pkg = ri.activityInfo.packageName
                    val icon = remember(pkg) { runCatching { ri.loadIcon(ctx.packageManager).toBitmap(160, 160).asImageBitmap() }.getOrNull() }
                    AppCard(ri.loadLabel(ctx.packageManager).toString(), icon, Color(0xFF444444), null) { onApp(pkg) }
                }
            }
        }
        if (films.isNotEmpty()) { SectionTitle("Фильмы и сериалы"); PosterRow(films, onFilm, null) }
        if (apps.isEmpty() && films.isEmpty()) Hint(if (hasKey) "Ничего не найдено" else "Приложения найдены не были. " + NEED_KEY)
    }
}

@Composable
fun AppsRow(custom: List<String>, onRemove: (String) -> Unit, onAdd: () -> Unit) {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(8.dp)) {
        rowItems(APPS) { item ->
            val icon = remember(item) { ctx.resolvePackage(item)?.let { runCatching { pm.getApplicationIcon(it).toBitmap(200, 200).asImageBitmap() }.getOrNull() } }
            AppCard(item.title, icon, item.accent, null) { ctx.launch(item) }
        }
        rowItems(custom) { pkg ->
            val label = remember(pkg) { runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg) }
            val icon = remember(pkg) { runCatching { pm.getApplicationIcon(pkg).toBitmap(200, 200).asImageBitmap() }.getOrNull() }
            AppCard(label, icon, Color(0xFF444444), { onRemove(pkg); Toast.makeText(ctx, "$label убрано с главного экрана", Toast.LENGTH_SHORT).show() }) { ctx.launchPackage(pkg) }
        }
        item {
            AppCard("Добавить", null, Color(0xFF2A2A2A), null, plus = true) { onAdd() }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCard(title: String, icon: ImageBitmap?, accent: Color, onLong: (() -> Unit)?, plus: Boolean = false, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.1f else 1f, tween(160), label = "s")
    val shape = RoundedCornerShape(22.dp)
    Box(
        Modifier.width(190.dp).height(118.dp).scale(scale)
            .then(if (focused) Modifier.shadow(18.dp, shape, ambientColor = Red, spotColor = Red) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .background(Glass, shape)
            .border(if (focused) 3.dp else 1.dp, if (focused) Red else GlassBorder, shape)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .focusable(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            when {
                plus -> Icon(painterResource(R.drawable.ic_add), null, Modifier.size(52.dp), tint = Color.White)
                icon != null -> Image(icon, title, Modifier.size(64.dp))
                else -> Box(Modifier.size(64.dp).background(accent, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Text(title.take(1).uppercase(), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(title, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 8.dp))
        }
    }
}

@Composable
fun PosterRow(films: List<Film>, onClick: (Film) -> Unit, onLong: ((Film) -> Unit)?) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(8.dp)) {
        rowItems(films) { f -> PosterCard(f, 150.dp, onLong?.let { l -> { l(f) } }) { onClick(f) } }
    }
}

@Composable
fun FilmGrid(films: List<Film>?, hasKey: Boolean, onClick: (Film) -> Unit) {
    when {
        !hasKey -> Hint(NEED_KEY)
        films == null -> Hint("Загрузка…")
        films.isEmpty() -> Hint("Ничего не загрузилось. Проверьте интернет и ключ.")
        else -> LazyVerticalGrid(GridCells.Adaptive(150.dp), contentPadding = PaddingValues(10.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            gridItems(films) { f -> PosterCard(f, 150.dp, null) { onClick(f) } }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PosterCard(f: Film, w: Dp, onLong: (() -> Unit)?, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.08f else 1f, tween(160), label = "s")
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.width(w).scale(scale)) {
        Box(
            Modifier.width(w).height(w * 1.45f)
                .then(if (focused) Modifier.shadow(18.dp, shape, ambientColor = Red, spotColor = Red) else Modifier)
                .onFocusChanged { focused = it.isFocused }
                .clip(shape).background(Color(0xFF1A1A1A))
                .border(if (focused) 3.dp else 0.dp, if (focused) Red else Color.Transparent, shape)
                .combinedClickable(onClick = onClick, onLongClick = onLong)
                .focusable()
        ) {
            AsyncImage(f.poster, f.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Spacer(Modifier.height(8.dp))
        Text(f.title, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(listOf(f.year, f.rating).filter { it.isNotBlank() }.joinToString(" · "), color = Color(0x99FFFFFF), fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun DetailScreen(f: Film, fav: Boolean, onWatch: () -> Unit, onFav: () -> Unit, onClose: () -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    Box(Modifier.fillMaxSize().background(Color(0xF0000000)).padding(56.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(40.dp)) {
            AsyncImage(f.poster, f.title, Modifier.width(260.dp).height(380.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.Crop)
            Column(Modifier.weight(1f)) {
                Text(f.title, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(listOf(if (f.series) "Сериал" else "Фильм", f.year, if (f.rating.isNotBlank()) "★ ${f.rating}" else "").filter { it.isNotBlank() }.joinToString("  ·  "), color = Color(0xCCFFFFFF), fontSize = 20.sp)
                Spacer(Modifier.height(32.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    ActionButton("Смотреть в КиноПоиске", true, first, onWatch)
                    ActionButton(if (fav) "Убрать из избранного" else "В избранное", false, null, onFav)
                    ActionButton("Закрыть", false, null, onClose)
                }
            }
        }
    }
}

@Composable
fun ActionButton(text: String, primary: Boolean, requester: FocusRequester?, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.08f else 1f, tween(160), label = "s")
    Box(
        Modifier.scale(scale).then(if (requester != null) Modifier.focusRequester(requester) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .background(if (primary) Red else Glass, RoundedCornerShape(30.dp))
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else GlassBorder, RoundedCornerShape(30.dp))
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 28.dp, vertical = 14.dp)
    ) { Text(text, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun AllApps(title: String, onPick: (String) -> Unit) {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    val apps = remember {
        ctx.allLaunchable().map { ri ->
            Triple(ri.activityInfo.packageName, ri.loadLabel(pm).toString(),
                runCatching { ri.loadIcon(pm).toBitmap(160, 160).asImageBitmap() }.getOrNull())
        }
    }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    Column(Modifier.fillMaxSize()) {
        Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(GridCells.Adaptive(150.dp), contentPadding = PaddingValues(10.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            gridItems(apps) { (pkg, label, icon) ->
                Box(if (pkg == apps.first().first) Modifier.focusRequester(first) else Modifier) {
                    AppCard(label, icon, Color(0xFF444444), null) { onPick(pkg) }
                }
            }
        }
    }
}

@Composable
fun SettingsButton(onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.12f else 1f, tween(160), label = "s")
    Box(
        Modifier.scale(scale).size(58.dp)
            .onFocusChanged { focused = it.isFocused }
            .background(if (focused) Color(0xFF2A2A2A) else Glass, RoundedCornerShape(50))
            .border(if (focused) 3.dp else 1.dp, if (focused) Red else GlassBorder, RoundedCornerShape(50))
            .clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) { Icon(painterResource(R.drawable.ic_gear), "Настройки", Modifier.size(30.dp), tint = Color.White) }
}

@Composable
fun VpnButton(on: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val color by animateColorAsState(if (on) Color(0xFF2ECC71) else Color(0xFFCCCCCC), tween(250), label = "c")
    val scale by animateFloatAsState(if (focused) 1.1f else 1f, tween(160), label = "s")
    Row(
        Modifier.scale(scale).height(58.dp)
            .onFocusChanged { focused = it.isFocused }
            .background(if (focused) Color(0xFF2A2A2A) else Glass, RoundedCornerShape(50))
            .border(if (focused) 3.dp else 1.dp, if (focused) Red else GlassBorder, RoundedCornerShape(50))
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 28.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(12.dp).background(color, RoundedCornerShape(50)))
        Spacer(Modifier.width(12.dp))
        Text(if (on) "VPN Вкл" else "VPN Выкл", color = color, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

package com.sharks.launcher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SearchResults(query: String, films: List<Film>, hasKey: Boolean, onFilm: (Film) -> Unit, onApp: (String) -> Unit) {
    val ctx = LocalContext.current
    val apps = remember(query) {
        ctx.allLaunchable().filter { it.loadLabel(ctx.packageManager).toString().contains(query, ignoreCase = true) }
    }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        if (apps.isNotEmpty()) {
            SectionTitle("Приложения")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(8.dp)) {
                rowItems(apps) { ri ->
                    val pkg = ri.activityInfo.packageName
                    val icon = remember(pkg) { runCatching { ri.loadIcon(ctx.packageManager).toBitmap(160, 160).asImageBitmap() }.getOrNull() }
                    AppCard(ri.loadLabel(ctx.packageManager).toString(), icon, Color(0xFF444444), null) { onApp(pkg) }
                }
            }
        }
        if (films.isNotEmpty()) { SectionTitle("Фильмы и сериалы"); PosterRow(films, onFilm, null) }
        if (apps.isEmpty() && films.isEmpty()) Hint(if (hasKey) "Ничего не найдено" else "Приложения найдены не были. " + NEED_KEY)
    }
}

/** Ряд на главном: порядок и состав редактируются (долгое нажатие на карточку → меню). */
@Composable
fun AppsRow(row: List<String>, onMenu: (String) -> Unit, onAdd: () -> Unit) {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(8.dp)) {
        rowItems(row, key = { it }) { key ->
            if (key.startsWith("d:")) {
                val item = APPS.firstOrNull { "d:" + it.title == key }
                if (item != null) {
                    val icon = remember(item) { ctx.resolvePackage(item)?.let { runCatching { pm.getApplicationIcon(it).toBitmap(200, 200).asImageBitmap() }.getOrNull() } }
                    AppCard(item.title, icon, item.accent, { onMenu(key) }) { ctx.launch(item) }
                }
            } else {
                val pkg = key.removePrefix("c:")
                val label = remember(pkg) { runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg) }
                val icon = remember(pkg) { runCatching { pm.getApplicationIcon(pkg).toBitmap(200, 200).asImageBitmap() }.getOrNull() }
                AppCard(label, icon, Color(0xFF444444), { onMenu(key) }) { ctx.launchPackage(pkg) }
            }
        }
        item {
            AppCard("Добавить", null, Color(0xFF2A2A2A), null, plus = true) { onAdd() }
        }
    }
}

@Composable
fun RecentRow(pkgs: List<String>) {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(8.dp)) {
        rowItems(pkgs, key = { it }) { pkg ->
            val label = remember(pkg) { runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg) }
            val icon = remember(pkg) { runCatching { pm.getApplicationIcon(pkg).toBitmap(200, 200).asImageBitmap() }.getOrNull() }
            AppCard(label, icon, Color(0xFF444444), null) { ctx.launchPackage(pkg) }
        }
    }
}

@Composable
fun PosterRow(films: List<Film>, onClick: (Film) -> Unit, onLong: ((Film) -> Unit)?) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(8.dp)) {
        rowItems(films) { f -> PosterCard(f, 150.dp, onLong?.let { l -> { l(f) } }) { onClick(f) } }
    }
}

@Composable
fun FilmGrid(films: List<Film>?, hasKey: Boolean, onRetry: () -> Unit, onClick: (Film) -> Unit) {
    when {
        !hasKey -> Hint(NEED_KEY)
        films == null -> Hint("Загрузка…")
        films.isEmpty() -> Retry("Ничего не загрузилось. Проверьте интернет и ключ.", onRetry)
        else -> LazyVerticalGrid(GridCells.Adaptive(150.dp), contentPadding = PaddingValues(10.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            gridItems(films) { f -> PosterCard(f, 150.dp, null) { onClick(f) } }
        }
    }
}

@Composable
fun InputsScreen() {
    val ctx = LocalContext.current
    val inputs = remember { ctx.tvInputs() }
    Column {
        SectionTitle("Входы")
        if (inputs.isEmpty()) {
            Hint("Входы не найдены. На ТВ-приставках без тюнера и HDMI-In этот раздел пуст; на телевизорах здесь появятся HDMI и AV.")
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(8.dp)) {
                rowItems(inputs, key = { it.id }) { i ->
                    AppCard(i.title, null, Color(0xFF444444), null, iconRes = R.drawable.ic_input) { ctx.openInput(i) }
                }
            }
        }
    }
}

@Composable
fun DetailScreen(f: Film, fav: Boolean, onWatch: () -> Unit, onFav: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val first = remember { FocusRequester() }
    var info by remember(f.id) { mutableStateOf<FilmInfo?>(null) }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    LaunchedEffect(f.id) { info = loadInfo(f.id) }
    Box(Modifier.fillMaxSize().background(Color(0xF0000000)).padding(48.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(36.dp)) {
            AsyncImage(f.poster, f.title, Modifier.width(240.dp).height(350.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.Crop)
            Column(Modifier.weight(1f)) {
                Text(f.title, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                Text(
                    listOf(if (f.series) "Сериал" else "Фильм", f.year, if (f.rating.isNotBlank()) "★ ${f.rating}" else "", info?.length ?: "")
                        .filter { it.isNotBlank() }.joinToString("  ·  "),
                    color = Color(0xCCFFFFFF), fontSize = 19.sp
                )
                info?.let { i ->
                    val meta = listOf(i.genres, i.countries).filter { it.isNotBlank() }.joinToString("  ·  ")
                    if (meta.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(meta, color = Color(0x99FFFFFF), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    if (i.description.isNotBlank()) {
                        Spacer(Modifier.height(14.dp))
                        Text(i.description, color = Color(0xDDFFFFFF), fontSize = 17.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
                    }
                }
                Spacer(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    ActionButton("Смотреть в КиноПоиске", true, first, onWatch)
                    info?.trailer?.let { url ->
                        ActionButton("Трейлер", false, null) {
                            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            catch (e: Exception) { Toast.makeText(ctx, "Не удалось открыть трейлер", Toast.LENGTH_LONG).show() }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    ActionButton(if (fav) "Убрать из избранного" else "В избранное", false, null, onFav)
                    ActionButton("Закрыть", false, null, onClose)
                }
            }
        }
    }
}

@Composable
fun AllApps(title: String, onPick: (String) -> Unit) {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    val apps = remember {
        ctx.allLaunchable().map { ri ->
            Triple(ri.activityInfo.packageName, ri.loadLabel(pm).toString(),
                runCatching { ri.loadIcon(pm).toBitmap(160, 160).asImageBitmap() }.getOrNull())
        }
    }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    Column(Modifier.fillMaxSize()) {
        Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(GridCells.Adaptive(150.dp), contentPadding = PaddingValues(10.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            gridItems(apps) { (pkg, label, icon) ->
                Box(if (pkg == apps.first().first) Modifier.focusRequester(first) else Modifier) {
                    AppCard(label, icon, Color(0xFF444444), null) { onPick(pkg) }
                }
            }
        }
    }
}

/** Меню по долгому нажатию на карточку приложения в ряду. */
@Composable
fun AppMenu(key: String, row: List<String>, onRow: (List<String>) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val item = if (key.startsWith("d:")) APPS.firstOrNull { "d:" + it.title == key } else null
    val pkg: String? = if (item != null) ctx.resolvePackage(item) else key.removePrefix("c:")
    val title = item?.title ?: pkg?.let { p ->
        runCatching { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(p, 0)).toString() }.getOrNull()
    } ?: key
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    Box(Modifier.fillMaxSize().background(Color(0xF2000000)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionButton(if (pkg != null) "Открыть" else "Установить", true, first) {
                    onClose()
                    if (item != null) ctx.launch(item) else if (pkg != null) ctx.launchPackage(pkg)
                }
                if (pkg != null) ActionButton("О приложении", false, null) { onClose(); ctx.appInfo(pkg) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionButton("←  Левее", false, null) { onRow(row.moved(key, -1)) }
                ActionButton("Правее  →", false, null) { onRow(row.moved(key, 1)) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionButton("Убрать с главного", false, null) { onRow(row.filter { it != key }); onClose() }
                if (pkg != null && !ctx.isSystemApp(pkg)) ActionButton("Удалить приложение", false, null) { onClose(); ctx.uninstall(pkg) }
            }
            ActionButton("Закрыть", false, null, onClose)
        }
    }
}

@Composable
fun WallpaperTile(w: Wallpaper, selected: Boolean, requester: FocusRequester?, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)
    Column(Modifier.width(150.dp)) {
        Box(
            Modifier.width(150.dp).height(84.dp)
                .then(if (requester != null) Modifier.focusRequester(requester) else Modifier)
                .onFocusChanged { focused = it.isFocused }
                .clip(shape)
                .border(if (focused) 3.dp else if (selected) 2.dp else 1.dp, if (focused) Color.White else if (selected) w.accent else GlassBorder, shape)
                .clickable(onClick = onClick).focusable()
        ) {
            WallpaperBackground(w)
            if (selected) Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp).size(20.dp).background(w.accent, RoundedCornerShape(50)),
                contentAlignment = Alignment.Center
            ) { Text("✓", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(6.dp))
        Text(w.label, color = if (selected) Color.White else Color(0xFFB0B0B0), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun KeyField(value: String, onChange: (String) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val kb = LocalSoftwareKeyboardController.current
    Box(
        Modifier.fillMaxWidth().height(56.dp)
            .background(Glass, RoundedCornerShape(28.dp))
            .border(if (focused) 3.dp else 1.dp, if (focused) Red else GlassBorder, RoundedCornerShape(28.dp))
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 20.sp),
            cursorBrush = SolidColor(Red),
            modifier = Modifier.fillMaxWidth()
                .onFocusChanged { focused = it.isFocused }
                .onPreviewKeyEvent { e ->
                    if (e.type == KeyEventType.KeyUp && (e.key == Key.DirectionCenter || e.key == Key.Enter)) { kb?.show(); true } else false
                },
            decorationBox = { inner ->
                if (value.isEmpty()) Text("Вставьте ключ API…", color = Color(0x99FFFFFF), fontSize = 20.sp)
                inner()
            }
        )
    }
}

/** Настройки самого лаунчера: обои, ключ КиноПоиска, ряд приложений, системные настройки. */
@Composable
fun SettingsScreen(
    wallpaper: Wallpaper, onWallpaper: (Wallpaper) -> Unit,
    apiKey: String, onKey: (String) -> Unit,
    onResetRow: () -> Unit, onSystem: () -> Unit, onClose: () -> Unit
) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    Column(
        Modifier.fillMaxSize().background(Color(0xF5000000))
            .padding(horizontal = 56.dp, vertical = 28.dp).verticalScroll(rememberScrollState())
    ) {
        Text("Настройки лаунчера", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        SectionTitle("Обои")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(4.dp)) {
            rowItems(Wallpaper.values().toList()) { w ->
                WallpaperTile(w, w == wallpaper, if (w == Wallpaper.values().first()) first else null) { onWallpaper(w) }
            }
        }
        SectionTitle("Ключ API КиноПоиска")
        KeyField(apiKey, onKey)
        Hint("Бесплатный ключ: kinopoiskapiunofficial.tech. Сохраняется на устройстве.")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            ActionButton("Сбросить ряд приложений", false, null, onResetRow)
            ActionButton("Системные настройки", false, null, onSystem)
            ActionButton("Готово", true, null, onClose)
        }
        Spacer(Modifier.height(20.dp))
    }
}

#!/usr/bin/env bash
# Настоящие скриншоты с ТВ/эмулятора по adb: все обои × все разделы.
# Использование: ./tools/screenshots.sh [ip:порт]   (adb connect при необходимости)
set -e
[ -n "$1" ] && adb connect "$1"
OUT=docs/real; mkdir -p "$OUT"
CMP=com.sharks.tv/com.sharks.launcher.MainActivity
shot() { adb exec-out screencap -p > "$OUT/$1.png"; echo "  $1"; }
for w in Waves Ocean Shark Sunset Neon Emerald Black; do
  adb shell am start -n $CMP --es wallpaper $w --es section Home >/dev/null; sleep 2; shot "wallpaper_$w"
done
adb shell am start -n $CMP --es wallpaper Waves >/dev/null
for s in Home Apps Movies Series Favs Inputs; do
  adb shell am start -n $CMP --es section $s >/dev/null; sleep 3; shot "section_$s"
done
adb shell am start -n $CMP --ez settings true >/dev/null; sleep 2; shot settings
adb shell am start -n $CMP --ez settings false --ez picker true >/dev/null; sleep 2; shot picker
echo "Готово: $OUT"

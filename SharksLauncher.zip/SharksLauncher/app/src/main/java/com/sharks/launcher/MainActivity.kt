package com.sharks.launcher

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay

/** Плитка приложения: список возможных пакетов (берётся первый установленный). */
data class AppItem(val title: String, val packages: List<String>, val accent: Color)

val HAPP_PACKAGES = listOf("com.happproxy", "com.happ.android")

val APPS = listOf(
    AppItem("YouTube", listOf("com.google.android.youtube.tv", "com.google.android.youtube"), Color(0xFFFF0033)),
    AppItem("Happ VPN", HAPP_PACKAGES, Color(0xFF19B5FE)),
    AppItem("Google Chrome", listOf("com.android.chrome", "com.chrome.beta"), Color(0xFF4285F4)),
    AppItem("Play Маркет", listOf("com.android.vending"), Color(0xFF34A853)),
    AppItem("Downloader", listOf("com.esaba.downloader"), Color(0xFFFF9800)),
    AppItem("Файлы", listOf("com.mixplorer", "com.google.android.apps.nbu.files", "com.android.documentsui",
        "com.google.android.documentsui", "com.android.fileexplorer", "com.droidlogic.FileBrower", "com.softwinner.TvdFileManager"), Color(0xFF9C6BFF)),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Launcher() }
    }
    // Лаунчер не закрывается кнопкой «Назад»
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}
}

fun Context.launchIntentFor(pkg: String): Intent? =
    packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: packageManager.getLaunchIntentForPackage(pkg)

fun Context.resolvePackage(item: AppItem): String? = item.packages.firstOrNull { launchIntentFor(it) != null }

fun Context.launch(item: AppItem) {
    val pkg = resolvePackage(item)
    if (pkg != null) launchIntentFor(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { startActivity(it) }
    else installApp(item)
}

/** Не установлено → страница приложения в Play Маркете. */
fun Context.installApp(item: AppItem) {
    val pkg = item.packages.first()
    val tries = listOf(
        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")),
    )
    for (t in tries) try { startActivity(t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
    Toast.makeText(this, "${item.title} не установлен. Установите через Downloader", Toast.LENGTH_LONG).show()
}

/** РЕАЛЬНОЕ состояние: есть ли сеть с транспортом VPN. Без имитации. */
fun Context.isVpnActive(): Boolean {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    @Suppress("DEPRECATION")
    return cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
}

/**
 * Android не даёт стороннему приложению включать чужой VPN, а публичного API у Happ нет.
 * Поэтому по умолчанию открывается Happ (там жмётся «Подключить»), а плашка сама покажет реальный статус.
 * Если в вашей версии Happ есть свой intent-action — впишите его сюда.
 */
const val HAPP_ACTION: String = ""

fun Context.toggleVpn() {
    val pkg = HAPP_PACKAGES.firstOrNull { launchIntentFor(it) != null }
    if (HAPP_ACTION.isNotBlank() && pkg != null) {
        try { sendBroadcast(Intent(HAPP_ACTION).setPackage(pkg)); return } catch (_: Exception) {}
    }
    launch(APPS[1])
}

@Composable
fun Launcher() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    var vpn by remember { mutableStateOf(ctx.isVpnActive()) }
    val startIndex = remember { prefs.getInt("last", 0).coerceIn(0, APPS.lastIndex) }
    val requesters = remember { List(APPS.size) { FocusRequester() } }

    LaunchedEffect(Unit) { requesters[startIndex].requestFocus() }
    LaunchedEffect(Unit) { while (true) { vpn = ctx.isVpnActive(); delay(1000) } }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VpnButton(vpn, Modifier.align(Alignment.TopEnd).padding(top = 40.dp, end = 56.dp)) { ctx.toggleVpn() }

        Column(Modifier.align(Alignment.CenterStart).padding(start = 56.dp)) {
            Text("SHARKS TRAID", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
            Text("VIDEO MAX", color = Color(0x99FFFFFF), fontSize = 14.sp, letterSpacing = 4.sp)
            Spacer(Modifier.height(48.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                APPS.forEachIndexed { idx, item ->
                    AppTile(item, requesters[idx]) {
                        prefs.edit().putInt("last", idx).apply()
                        ctx.launch(item)
                    }
                }
            }
        }
    }
}

@Composable
fun AppTile(item: AppItem, requester: FocusRequester, onClick: () -> Unit) {
    val ctx = LocalContext.current
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.14f else 1f, tween(160), label = "s")
    val border by animateColorAsState(if (focused) Color.White else Color(0x22FFFFFF), tween(160), label = "b")
    val bg by animateColorAsState(if (focused) Color(0xFF1C1C1E) else Color(0xFF0E0E10), tween(160), label = "bg")
    val icon = remember(item) {
        ctx.resolvePackage(item)?.let { runCatching { ctx.packageManager.getApplicationIcon(it).toBitmap(256, 256).asImageBitmap() }.getOrNull() }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(150.dp).scale(scale)) {
        Box(
            Modifier.size(150.dp)
                .focusRequester(requester)
                .onFocusChanged { focused = it.isFocused }
                .background(bg, RoundedCornerShape(30.dp))
                .border(if (focused) 4.dp else 1.dp, border, RoundedCornerShape(30.dp))
                .clickable(onClick = onClick)
                .focusable(),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) Image(icon, item.title, Modifier.size(96.dp))
            else Box(Modifier.size(96.dp).background(item.accent, RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                Text(item.title.first().toString(), color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(item.title, color = if (focused) Color.White else Color(0x99FFFFFF), fontSize = 16.sp, maxLines = 1)
    }
}

@Composable
fun VpnButton(on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val color by animateColorAsState(if (on) Color(0xFF2ECC71) else Color(0xFF8A8A8E), tween(250), label = "c")
    val scale by animateFloatAsState(if (focused) 1.1f else 1f, tween(160), label = "s")
    Row(
        modifier.scale(scale)
            .onFocusChanged { focused = it.isFocused }
            .background(if (focused) Color(0xFF1C1C1E) else Color(0xFF0E0E10), RoundedCornerShape(50))
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else color.copy(alpha = .5f), RoundedCornerShape(50))
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 28.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(12.dp).background(color, RoundedCornerShape(50)))
        Spacer(Modifier.width(12.dp))
        Text("VPN  " + if (on) "ВКЛ" else "ВЫКЛ", color = color, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

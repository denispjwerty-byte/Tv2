package com.sharks.launcher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Обои рисуются кодом (без картинок): вес APK не растёт, цвет акцента меняется вместе с обоями. */
enum class Wallpaper(val label: String, val accent: Color) {
    Waves("Красные волны", Color(0xFFE50914)),
    Ocean("Глубина", Color(0xFF1E88E5)),
    Shark("Акулий плавник", Color(0xFF00B8D4)),
    Sunset("Закат", Color(0xFFFF6D00)),
    Neon("Неон", Color(0xFFD500F9)),
    Emerald("Изумруд", Color(0xFF00C853)),
    Black("Чёрный", Color(0xFFE50914))
}

private fun DrawScope.glow(c: Color, cx: Float, cy: Float, r: Float, a: Float) {
    drawRect(Brush.radialGradient(listOf(c.copy(alpha = a), Color.Transparent), center = Offset(cx, cy), radius = r))
}

private fun DrawScope.waves(c: Color, y0: Float, c1: Float, c2: Float, y1: Float, n: Int, a0: Float) {
    for (k in 0 until n) {
        val p = Path().apply {
            moveTo(size.width * 0.2f, size.height * (y0 + k * 0.04f))
            cubicTo(size.width * 0.5f, size.height * (c1 + k * 0.05f), size.width * 0.7f, size.height * (c2 - k * 0.05f), size.width, size.height * (y1 + k * 0.04f))
        }
        drawPath(p, c.copy(alpha = (a0 - k * 0.05f).coerceAtLeast(0.03f)), style = Stroke(width = 3f + k * 3f))
    }
}

@Composable
fun WallpaperBackground(w: Wallpaper, modifier: Modifier = Modifier.fillMaxSize()) {
    Canvas(modifier) {
        val W = size.width
        val H = size.height
        drawRect(Color.Black)
        when (w) {
            Wallpaper.Waves -> {
                glow(Color(0xFFE50914), W * 0.75f, 0f, W * 0.6f, 0.40f)
                glow(Color(0xFFB00020), 0f, H * 0.4f, W * 0.4f, 0.27f)
                waves(Color(0xFFE50914), 0.6f, 0.15f, 0.95f, 0.3f, 4, 0.28f)
            }
            Wallpaper.Ocean -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF031D3A), Color(0xFF020B16), Color.Black)))
                glow(Color(0xFF1E88E5), W * 0.2f, 0f, W * 0.6f, 0.35f)
                waves(Color(0xFF42A5F5), 0.72f, 0.35f, 1.0f, 0.55f, 5, 0.30f)
                for (i in 0 until 9) {
                    val x = W * (0.12f + i * 0.1f)
                    val y = H * (0.25f + (i * 37 % 50) / 100f)
                    drawCircle(Color(0x4442A5F5), radius = 4f + (i % 3) * 3f, center = Offset(x, y), style = Stroke(2f))
                }
            }
            Wallpaper.Shark -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF002B36), Color(0xFF00090D), Color.Black)))
                glow(Color(0xFF00B8D4), W * 0.72f, H * 0.55f, W * 0.55f, 0.28f)
                val x0 = W * 0.66f
                val y = H * 0.74f
                val fin = Path().apply {
                    moveTo(x0, y)
                    quadraticBezierTo(x0 + 0.05f * W, y - 0.10f * H, x0 + 0.085f * W, y - 0.26f * H)
                    quadraticBezierTo(x0 + 0.09f * W, y - 0.09f * H, x0 + 0.16f * W, y)
                    close()
                }
                drawPath(fin, Color(0xFF031319))
                drawPath(fin, Color(0xCC00B8D4), style = Stroke(width = 4f))
                drawRect(Color(0xCC000000), topLeft = Offset(0f, y), size = Size(W, H - y))
                waves(Color(0xFF00B8D4), 0.74f, 0.70f, 0.78f, 0.74f, 4, 0.50f)
            }
            Wallpaper.Sunset -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF0D0020), Color(0xFF3A0F3A), Color(0xFFB34A1A), Color.Black)))
                drawCircle(Brush.radialGradient(listOf(Color(0xFFFFB040), Color(0x00FF6D00)), center = Offset(W * 0.5f, H * 0.55f), radius = H * 0.28f),
                    radius = H * 0.28f, center = Offset(W * 0.5f, H * 0.55f))
                drawRect(Color.Black, topLeft = Offset(0f, H * 0.7f), size = Size(W, H * 0.3f))
                for (i in 0 until 6) {
                    val rw = W * (0.22f - i * 0.03f)
                    drawLine(Color(0xFFFF6D00).copy(alpha = 0.55f - i * 0.08f), Offset(W * 0.5f - rw, H * (0.72f + i * 0.035f)), Offset(W * 0.5f + rw, H * (0.72f + i * 0.035f)), 4f)
                }
            }
            Wallpaper.Neon -> {
                val hz = H * 0.55f
                glow(Color(0xFFD500F9), W * 0.85f, 0f, W * 0.6f, 0.35f)
                glow(Color(0xFF00E5FF), 0f, H, W * 0.5f, 0.25f)
                drawCircle(Brush.verticalGradient(listOf(Color(0xFFFFEA00), Color(0xFFD500F9)), startY = hz - 0.2f * H, endY = hz),
                    radius = 0.18f * H, center = Offset(W * 0.5f, hz - 0.02f * H))
                drawRect(Color.Black, topLeft = Offset(0f, hz), size = Size(W, H - hz))
                for (i in 0..10) {
                    val t = i / 10f
                    val gy = hz + (H - hz) * t * t
                    drawLine(Color(0xFFD500F9).copy(alpha = 0.35f), Offset(0f, gy), Offset(W, gy), 2f)
                }
                for (i in -8..8) {
                    drawLine(Color(0xFF00E5FF).copy(alpha = 0.25f), Offset(W * 0.5f + i * W * 0.03f, hz), Offset(W * 0.5f + i * W * 0.12f, H), 2f)
                }
            }
            Wallpaper.Emerald -> {
                glow(Color(0xFF00C853), W * 0.75f, 0f, W * 0.6f, 0.38f)
                glow(Color(0xFF00695C), 0f, H * 0.4f, W * 0.4f, 0.30f)
                waves(Color(0xFF00E676), 0.55f, 0.15f, 0.95f, 0.3f, 4, 0.28f)
            }
            Wallpaper.Black -> Unit
        }
    }
}

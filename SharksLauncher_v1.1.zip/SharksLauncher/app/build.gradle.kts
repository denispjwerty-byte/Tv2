import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Секреты берутся из переменных окружения (CI) или local.properties (локально) — в код не попадают.
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun secret(name: String): String = System.getenv(name) ?: localProps.getProperty(name) ?: ""

android {
    namespace = "com.sharks.launcher"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.sharks.tv"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
        buildConfigField("String", "KP_API_KEY", "\"${secret("KP_API_KEY")}\"")
    }
    signingConfigs {
        create("fixed") {
            // Без переменных окружения используется прежний sharks.jks — сборка не ломается.
            storeFile = file(System.getenv("KEYSTORE_FILE") ?: "sharks.jks")
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "sharks123"
            keyAlias = System.getenv("KEY_ALIAS") ?: "sharks"
            keyPassword = System.getenv("KEY_PASSWORD") ?: "sharks123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        release { isMinifyEnabled = false }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("io.coil-kt:coil-compose:2.6.0")
}
